The correct choice is 4. `\b(2|two|3|three)\s*(day|days)\b`.

#