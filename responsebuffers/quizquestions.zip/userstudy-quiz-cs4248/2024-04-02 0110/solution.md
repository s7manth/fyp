The correct choice is:

4. L2 regularization adds a penalty to the size of the weights, encouraging smaller, more diffuse weight values, which helps in reducing overfitting.